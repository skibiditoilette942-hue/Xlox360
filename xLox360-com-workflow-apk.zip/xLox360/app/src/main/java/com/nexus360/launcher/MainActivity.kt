package com.xlox360.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 11, 14)
    private val panel = Color.rgb(19, 25, 30)
    private val green = Color.rgb(124, 255, 0)
    private val white = Color.rgb(240, 246, 248)
    private val muted = Color.rgb(153, 167, 174)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var clock: TextView
    private var currentTab = "INÍCIO"
    private val prefs by lazy { getSharedPreferences("xlox360", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildShell()
        showHome()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(30), dp(20), dp(30), dp(20))
            setBackgroundColor(bg)
            isFocusableInTouchMode = true
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "xLox 360"
            textSize = 27f; setTextColor(white); typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.06f
        }
        val stripe = TextView(this).apply { text = "  ■"; textSize = 22f; setTextColor(green) }
        val spacer = Space(this)
        clock = TextView(this).apply { textSize = 17f; setTextColor(muted); gravity = Gravity.CENTER_VERTICAL }
        header.addView(logo); header.addView(stripe); header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f)); header.addView(clock)
        root.addView(header, LinearLayout.LayoutParams(-1, dp(42)))
        val subtitle = TextView(this).apply { text = "SUA CENTRAL DE JOGOS E APLICATIVOS"; textSize = 10f; letterSpacing = 0.22f; setTextColor(green) }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(22)))
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, dp(14)) }
        listOf("INÍCIO", "APLICATIVOS", "FAVORITOS", "CONFIGURAÇÕES").forEach { tab ->
            val b = TextView(this).apply {
                text = tab; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (tab == currentTab) green else muted)
                setPadding(dp(16), dp(10), dp(16), dp(10)); isFocusable = true; isClickable = true
                background = rounded(if (tab == currentTab) 0x333CFF00 else 0x00111111, 8)
                setOnClickListener { currentTab = tab; refresh() }
            }
            tabs.addView(b)
        }
        root.addView(tabs)
        val line = View(this).apply { setBackgroundColor(Color.rgb(43, 57, 62)) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(18), 0, 0) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = TextView(this).apply { text = "xLOX OS  •  RETRO-FUTURISTA  •  OFFLINE READY"; textSize = 9f; letterSpacing = 0.12f; setTextColor(Color.rgb(90, 108, 116)) }
        root.addView(footer)
        setContentView(root)
        updateClock()
    }

    override fun onResume() { super.onResume(); if (::root.isInitialized) { updateClock(); refresh() } }

    private fun updateClock() {
        if (!::clock.isInitialized) return
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val greeting = when (hour) { in 5..11 -> "BOM DIA"; in 12..17 -> "BOA TARDE"; else -> "BOA NOITE" }
        clock.text = "$greeting   •   $time"
    }

    private fun refresh() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        when (currentTab) {
            "APLICATIVOS" -> showApps(false)
            "FAVORITOS" -> showApps(true)
            "CONFIGURAÇÕES" -> showSettings()
            else -> showHome()
        }
    }

    private fun showHome() {
        content.removeAllViews()
        val title = TextView(this).apply { text = "ESCOLHA SUA PRÓXIMA AVENTURA"; textSize = 23f; typeface = Typeface.create("sans-serif-black", Typeface.BOLD); setTextColor(white) }
        content.addView(title)
        val desc = TextView(this).apply { text = "Seus aplicativos, seus jogos, do seu jeito."; textSize = 14f; setTextColor(muted); setPadding(0, dp(6), 0, dp(18)) }
        content.addView(desc)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val apps = launcherApps()
        val favorites = apps.filter { isFavorite(it.packageName) }
        val featured = (favorites + apps.filterNot { isFavorite(it.packageName) }).distinctBy { it.packageName }.take(5)
        if (featured.isEmpty()) {
            val empty = TextView(this).apply { text = "Nenhum aplicativo compatível foi encontrado."; setTextColor(muted); textSize = 16f }
            content.addView(empty)
        } else featured.forEach { app -> row.addView(appCard(app, true), LinearLayout.LayoutParams(0, dp(155), 1f).apply { marginEnd = dp(10) }) }
        content.addView(row)
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(20), 0, 0) }
        quick.addView(actionButton("＋  ADICIONAR / VER APPS") { currentTab = "APLICATIVOS"; refresh() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(10) })
        quick.addView(actionButton("⚙  CONFIGURAÇÕES") { currentTab = "CONFIGURAÇÕES"; refresh() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        content.addView(quick)
        content.addView(TextView(this).apply { text = "DICA: use as setas do controle e pressione OK para abrir."; setTextColor(muted); textSize = 12f; setPadding(0, dp(18), 0, 0) })
    }

    private data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable?)

    private fun launcherApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            packageManager.queryIntentActivities(intent, 0)
                .mapNotNull { info ->
                    val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                    if (pkg == packageName) return@mapNotNull null
                    AppEntry(info.loadLabel(packageManager)?.toString() ?: pkg, pkg, info.loadIcon(packageManager))
                }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        } catch (_: Exception) { emptyList() }
    }

    private fun showApps(favoritesOnly: Boolean) {
        val heading = TextView(this).apply { text = if (favoritesOnly) "SEUS FAVORITOS" else "APLICATIVOS INSTALADOS"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white); setPadding(0, 0, 0, dp(12)) }
        content.addView(heading)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val apps = launcherApps().filter { !favoritesOnly || isFavorite(it.packageName) }
        if (apps.isEmpty()) list.addView(TextView(this).apply { text = if (favoritesOnly) "Ainda não há favoritos. Abra Aplicativos e use ☆ para favoritar." else "Não foram encontrados aplicativos para iniciar."; setTextColor(muted); textSize = 14f; setPadding(dp(8), dp(12), dp(8), dp(12)) })
        apps.forEach { app ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(0xFF13191E.toInt(), 10); setPadding(dp(12), dp(8), dp(12), dp(8)); isFocusable = true }
            val icon = ImageView(this).apply { setImageDrawable(app.icon); scaleType = ImageView.ScaleType.FIT_CENTER }
            item.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            labels.addView(TextView(this).apply { text = app.label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white) })
            labels.addView(TextView(this).apply { text = app.packageName; textSize = 10f; setTextColor(muted) })
            item.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val fav = TextView(this).apply { text = if (isFavorite(app.packageName)) "★" else "☆"; textSize = 25f; setTextColor(green); gravity = Gravity.CENTER; isFocusable = true; setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { toggleFavorite(app.packageName); refresh() } }
            item.addView(fav)
            item.setOnClickListener { launchApp(app.packageName) }
            item.setOnKeyListener { _, key, event -> if (event.action == KeyEvent.ACTION_UP && (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER)) { launchApp(app.packageName); true } else false }
            list.addView(item, LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(7) })
        }
        scroll.addView(list)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun showSettings() {
        val title = TextView(this).apply { text = "CONFIGURAÇÕES DO xLox"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white); setPadding(0, 0, 0, dp(16)) }
        content.addView(title)
        content.addView(actionButton("ABRIR CONFIGURAÇÕES DO ANDROID") { openSettings() }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })
        content.addView(actionButton("ESCOLHER LAUNCHER PADRÃO (SE DISPONÍVEL)") {
            try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
            catch (_: Exception) { AlertDialog.Builder(this).setMessage("Abra Configurações do Android e procure por Aplicativos padrão ou Tela inicial.").setPositiveButton("OK", null).show() }
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })
        content.addView(actionButton("VER APLICATIVOS INSTALADOS") { currentTab = "APLICATIVOS"; refresh() }, LinearLayout.LayoutParams(-1, dp(52)))
        content.addView(TextView(this).apply { text = "O Android pode limitar a troca de launcher em algumas TV Boxes. O xLox não precisa de root."; textSize = 12f; setTextColor(muted); setPadding(0, dp(18), 0, 0) })
    }

    private fun appCard(app: AppEntry, showFavorite: Boolean): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(0xFF13191E.toInt(), 12); setPadding(dp(8), dp(10), dp(8), dp(10)); isFocusable = true; isClickable = true }
        val icon = ImageView(this).apply { setImageDrawable(app.icon); scaleType = ImageView.ScaleType.FIT_CENTER }
        box.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
        box.addView(TextView(this).apply { text = app.label; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white); gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(8), 0, 0) })
        if (showFavorite) box.addView(TextView(this).apply { text = if (isFavorite(app.packageName)) "★ FAVORITO" else "ABRIR"; textSize = 9f; setTextColor(green); setPadding(0, dp(5), 0, 0) })
        box.setOnClickListener { launchApp(app.packageName) }
        box.setOnFocusChangeListener { v, hasFocus -> v.background = rounded(if (hasFocus) 0xFF26351F.toInt() else 0xFF13191E.toInt(), 12, if (hasFocus) green else Color.TRANSPARENT) }
        return box
    }

    private fun actionButton(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(white); isFocusable = true; isClickable = true
        background = rounded(0xFF192126.toInt(), 9, Color.rgb(43, 57, 62)); setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { action() }
        setOnFocusChangeListener { v, focus -> v.background = rounded(if (focus) 0xFF26351F.toInt() else 0xFF192126.toInt(), 9, if (focus) green else Color.rgb(43, 57, 62)) }
    }

    private fun launchApp(pkg: String) {
        try { val intent = packageManager.getLaunchIntentForPackage(pkg); if (intent != null) startActivity(intent) else Toast.makeText(this, "Este aplicativo não oferece um atalho de inicialização.", Toast.LENGTH_SHORT).show() }
        catch (_: ActivityNotFoundException) { Toast.makeText(this, "Não foi possível abrir o aplicativo.", Toast.LENGTH_SHORT).show() }
    }

    private fun openSettings() { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { Toast.makeText(this, "Configurações indisponíveis neste dispositivo.", Toast.LENGTH_SHORT).show() } }
    private fun isFavorite(pkg: String) = prefs.getBoolean("fav_$pkg", false)
    private fun toggleFavorite(pkg: String) { prefs.edit().putBoolean("fav_$pkg", !isFavorite(pkg)).apply() }
    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (currentTab != "INÍCIO") { currentTab = "INÍCIO"; refresh(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }
}
