# xLox 360 — Android TV launcher (starter project)

Projeto nativo Android em Kotlin, sem WebView/HTML, com interface horizontal, foco para controle remoto, lista de apps iniciáveis, favoritos persistentes, relógio/saudação e atalhos para Configurações.

## Compilar
1. Abra a pasta `xLox360` no Android Studio.
2. Aguarde a sincronização do Gradle (requer internet na primeira compilação para baixar o plugin Android/Gradle e o SDK correspondente).
3. Se solicitado, instale Android SDK Platform 35 e Build Tools compatíveis.
4. Use **Build > Build APK(s)**. O APK de debug costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.
5. Instale o APK na TV Box e, se o Android oferecer a opção, escolha xLox 360 como app de tela inicial.

## Limitações importantes
- Este ambiente não tem Android SDK/Gradle instalado, então o APK não foi compilado nem testado aqui; o arquivo entregue é o projeto-fonte.
- A aparência e a troca de launcher dependem da versão e das restrições do fabricante da TV Box.
- A descrição dos jogos ainda não é editável nesta primeira versão; esta base implementa a tela inicial, aplicativos e favoritos funcionais.


## Ajustes para TV (versão atualizada)
- Nome do aplicativo: xLox 360.
- Orientação da atividade fixada em landscape (horizontal).
- Categorias de launcher Android e Android TV/Leanback declaradas.
- Tela imersiva e navegação por controle remoto mantidas.

Este pacote contém o código-fonte; o APK ainda precisa ser compilado e testado em um dispositivo Android TV Box.
